    @{
        Name           = "Test"
        Repo           = "" # Enter the repository path here
        AuthMethod     = "Authenticate-TestRepo"
        SetupMethod    = "Configure-TestRepo"
        BuildMethod    = "Build-TestRepo"
        TestMethod     = "Test-TestRepo"
        RunMethod      = "Execute-TestRepo"
        DevMethod      = "Develop-TestRepo"
        GoLocations    = @{}
    }

